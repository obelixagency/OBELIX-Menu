import { NextRequest, NextResponse } from "next/server";
import { requireMenuEditor } from "@/lib/auth";
import { deleteBanner, updateBanner } from "@/lib/menu-data";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const denied = await requireMenuEditor();
  if (denied) return denied;
  const { id } = await ctx.params;
  try {
    const body = await req.json();
    const banner = await updateBanner(id, body);
    return NextResponse.json({ banner });
  } catch (err) {
    const message = err instanceof Error ? err.message : "فشل";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const denied = await requireMenuEditor();
  if (denied) return denied;
  const { id } = await ctx.params;
  await deleteBanner(id);
  return NextResponse.json({ ok: true });
}

import { readBrand, toPublicBrand } from "@/lib/brand";
import {
  isPromoEnabled,
  listBanners,
  listCategories,
  listContacts,
  listProducts,
  listReviews,
  toPublicReview,
} from "@/lib/menu-data";
import { getStockMap, isInventoryOn } from "@/lib/inventory-data";
import {
  applyBranchToProduct,
  getBranch,
  isMultiBranchOn,
  resolveBranchId,
} from "@/lib/branches-data";
import { getOrderingSettings } from "@/lib/ordering-data";
import { inSchedule } from "@/lib/commerce";
import { PublicMenu } from "@/components/menu/public-menu";

type Props = { searchParams: Promise<{ branch?: string }> };

export default async function HomePage({ searchParams }: Props) {
  const sp = await searchParams;
  const multi = await isMultiBranchOn();
  const branchId = await resolveBranchId(sp.branch || null);
  const branch = multi ? await getBranch(branchId) : null;

  const [brand, categories, productsRaw, contacts, reviews, banners, invOn, promoOn, ordering] =
    await Promise.all([
      readBrand(),
      listCategories(),
      listProducts(),
      listContacts(),
      listReviews(),
      listBanners(),
      isInventoryOn(),
      isPromoEnabled(),
      getOrderingSettings(),
    ]);

  const products = await Promise.all(
    productsRaw.map((p) => applyBranchToProduct(branchId, p))
  );
  const stockMap = invOn ? await getStockMap(branchId) : {};

  return (
    <PublicMenu
      brand={toPublicBrand(brand)}
      categories={categories}
      products={products}
      contacts={contacts}
      reviews={reviews.filter((r) => r.visible).map(toPublicReview)}
      banners={
        promoOn
          ? banners.filter((b) => b.active && inSchedule(b.startsAt, b.endsAt))
          : []
      }
      stockMap={stockMap}
      inventoryEnabled={invOn}
      branchId={branchId}
      branchLabel={branch?.name}
      seasonalNote={ordering.seasonalNote}
      seasonalNoteEn={ordering.seasonalNoteEn}
    />
  );
}
